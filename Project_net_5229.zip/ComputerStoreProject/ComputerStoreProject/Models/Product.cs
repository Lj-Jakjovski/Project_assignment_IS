﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace ComputerStoreProject.Models
{
    public class Product
    {
        public int Id { get; set; }
        [MaxLength(100)]
        public string Name { get; set; } = "";
        [MaxLength(100)]
        public string Description { get; set; } = "";
        [Precision(16,2)]
        public string Price { get; set; } = "";
        [MaxLength(100)]
        public string Brand { get; set; } = "";
        
    }
}
