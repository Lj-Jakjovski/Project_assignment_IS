﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace ComputerStoreProject.Models
{
    public class ProductDto
    {
        [Required, MaxLength(100)]
        public string Name { get; set; } = "";
        [Required]
        public string Description { get; set; } = "";
        [Required]
        public string Price { get; set; } = "";
        [Required, MaxLength(100)]
        public string Brand { get; set; } = "";
    }
}
